// for sticky header
function menu_open() {
  jQuery(".main-menu").css({ "transform": "translateX(0)" })
}
function menu_close() {
  jQuery(".main-menu").css({ "transform": "translateX(600px)" })
}


// function menu_open() {
//   jQuery(".main-menu").css({ "right": "0" })
// }
// function menu_close() {
//   jQuery(".main-menu").css({ "right": "-50%" })
// }


jQuery(window).scroll(function () {
  if (jQuery(window).scrollTop() >= 200) {
    jQuery('body').addClass('header-sticky');
  }
  else {
    jQuery('body').removeClass('header-sticky');
  }
});

jQuery(document).ready(function () {
  jQuery('.nav_btn').click(function () {
    jQuery('html, body').toggleClass('menu-open');
  });
  jQuery('.nav_close').click(function () {
    jQuery('html, body').removeClass('menu-open');
  });

 

});


jQuery(document).ready(function () {

  jQuery(".menu-item-has-children").prepend("<span class='plus'>+</span><span class='minus'>-</span>");
  jQuery(".plus").click(function () {
    jQuery(".menu-item-has-children").removeClass("open-sub");
    jQuery(this).parent().addClass("open-sub");
  });
  jQuery(".minus").click(function () {
    jQuery(this).parent().removeClass("open-sub");
  });
  jQuery(".menu-button").click(function () {
    jQuery(".menu-item-has-children").removeClass("open-sub");
    jQuery(this).parent().toggleClass("tadaa");
  });
});

    jQuery(document).ready(function() {

    jQuery(".accordion").accordion();

   

    jQuery('.home-needs-slider').slick({
      centerMode: false,
      autoplay: true,
      infinite: true,
      slidesToShow: 2,
      slidesToScroll: 1,
      dots: false,
      arrows: false,
      responsive: [
         
          {
            breakpoint: 1200,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1
            }
          },

          {
            breakpoint: 992,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
             // autoplay: true,
              dots: true,
              arrows: false,
            }
          },
        
         
        ]

     
  });

  jQuery('.home-needs-slider-new').slick({
      centerMode: true,
      autoplay: true,
      infinite: true,
      slidesToShow: 2,
      slidesToScroll: 1,
      dots: false,
      arrows: false,
      responsive: [
         
          {
            breakpoint: 1200,
            settings: {
              slidesToShow: 2,
              slidesToScroll: 1
            }
          },

          {
            breakpoint: 992,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
             // autoplay: true,
              dots: true,
              arrows: false,
            }
          },
        
         
        ]

     
  });


   //testimonial slider
   jQuery('.testimonial-slider').slick({
    centerMode: true,
    autoplay: false,
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    dots: false,
    arrow: true,
    // prevArrow: '.testimonial-prev',
    // nextArrow: '.testimonial-next',

    responsive: [
       
        {
          breakpoint: 1025,
          settings: {
            slidesToShow: 1,
          },
        },
       
      ],
});

 
});

// jQuery(document).ready(function() {


// });